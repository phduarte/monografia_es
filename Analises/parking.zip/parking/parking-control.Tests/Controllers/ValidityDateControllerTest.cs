﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using parking_control;
using parking_control.Controllers;
using parking_control.Models;

namespace parking_control.Tests.Controllers
{
    [TestClass]
    public class ValidityDateControllerTest
    {
        
    }
}
