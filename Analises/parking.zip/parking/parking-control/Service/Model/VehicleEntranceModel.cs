﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using parking_control.Models;

namespace parking_control.Service.Model
{
    public class VehicleEntranceModel : BaseModel
    {
        public static void Insert(VehicleEntrance vehicle)
        {
            using (MySqlCommand command = new MySqlCommand(GetInsertVehicleSql(vehicle), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }

        private static string GetInsertVehicleSql(VehicleEntrance vehicle)
        {

            return string.Format(
                    "INSERT INTO VehicleEntrance (HourPrice, Board, DateIn, DateOut, PriceCharged) VALUES ({0}, \"{1}\", \"{2}\", \"{3}\", {4});"
                    , MySqlHelper.DoubleQuoteString(vehicle.HourPrice.ToString()).Replace(",", "."), vehicle.Board, vehicle.DateIn.ToString("yyyy-MM-dd HH:mm:ss"), vehicle.DateOut.ToString("yyyy-MM-dd HH:mm:ss"), MySqlHelper.DoubleQuoteString(vehicle.PriceCharged.ToString()).Replace(",", "."));
        }

        public static VehicleEntrance Select(string vehicleBoard)
        {
            return RunCommand(vehicleBoard, string.Format("SELECT * FROM VehicleEntrance WHERE Board = \"{0}\"", vehicleBoard));
        }

        private static VehicleEntrance RunCommand(string vehicleBoard, string sql)
        {
            using (MySqlCommand command = new MySqlCommand(sql, ConnectMysql.GetInstance()))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    ValidateReader(reader);

                    return CreateVehicle(vehicleBoard, reader);
                }
            }
        }

        private static VehicleEntrance CreateVehicle(string vehicleBoard, MySqlDataReader reader)
        {
            VehicleEntrance vehicle = new VehicleEntrance(reader.GetInt32(0), vehicleBoard, reader.GetDateTime(3))
            {
                DateOut = reader.GetDateTime(4),
                HourPrice = reader.GetDouble(1),
                PriceCharged = reader.GetDouble(5)
            };
            return vehicle;
        }

        public static VehicleEntrance Select(int id)
        {
            Validate(id);

           return RunCommand(id, string.Format("SELECT * FROM VehicleEntrance WHERE id = {0}", id));
        }

        private static VehicleEntrance RunCommand(int id, string sql)
        {
            using (MySqlCommand command = new MySqlCommand(sql, ConnectMysql.GetInstance()))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    ValidateReader(reader);

                    return  CreateVehicle(id, reader);
                }
            }            
        }

        private static VehicleEntrance CreateVehicle(int id, MySqlDataReader reader)
        {


            return new VehicleEntrance(id, reader.GetString(2), reader.GetDateTime(3))
            {
                HourPrice = reader.GetDouble(1),
                PriceCharged = reader.GetDouble(5),
                DateOut = reader.GetDateTime(4),
            };
        }

        public static List<VehicleEntrance> SelectAll(int limit = 1000)
        {
            List<VehicleEntrance> list = new List<VehicleEntrance>();
            using (MySqlCommand command = new MySqlCommand(string.Format("SELECT * FROM VehicleEntrance LIMIT {0}", limit), ConnectMysql.GetInstance()))
            {
                ExecuteCommand(list, command);
            }
            return list;
        }

        private static void ExecuteCommand(List<VehicleEntrance> list, MySqlCommand command)
        {
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    AddVehicleToList(list, reader);
                }
            }
        }

        private static void AddVehicleToList(List<VehicleEntrance> list, MySqlDataReader reader)
        {
            VehicleEntrance ve = new VehicleEntrance(reader.GetInt32(0), reader.GetString(2), reader.GetDateTime(3))
            {
                HourPrice = reader.GetDouble(1),
                DateOut = reader.GetDateTime(4)
            };
            list.Add(ve);
        }

        public static void Update(VehicleEntrance vehicle)
        {
            Validate(vehicle);

            using (MySqlCommand command = new MySqlCommand(GenerateUpdateSql(vehicle), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }

        private static string GenerateUpdateSql(VehicleEntrance vehicle)
        {
           return  string.Format(
                    "UPDATE VehicleEntrance SET HourPrice={0}, Board=\"{1}\", DateIn=\"{2}\", DateOut=\"{3}\", PriceCharged={4} WHERE id = {5};"
                    , MySqlHelper.DoubleQuoteString(vehicle.HourPrice.ToString()).Replace(",", "."), vehicle.Board, vehicle.DateIn.ToString("yyyy-MM-dd HH:mm:ss"), vehicle.DateOut.ToString("yyyy-MM-dd HH:mm:ss"), MySqlHelper.DoubleQuoteString(vehicle.PriceCharged.ToString()).Replace(",", "."), vehicle.ID);
        }

        private static void Validate(VehicleEntrance vehicle)
        {
            if (vehicle.ID == 0)
                throw new NotFoundIDEntity("A objeto atualizado não possue uma chave primária");
        }

        public static void Delete(VehicleEntrance vehicle)
        {
            DeleteByID(vehicle.ID);
        }

        public static void DeleteByID(int id)
        {
            Validate(id);

            using (MySqlCommand command = new MySqlCommand(string.Format("DELETE FROM VehicleEntrance WHERE id = {0}", id), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }
    }
}