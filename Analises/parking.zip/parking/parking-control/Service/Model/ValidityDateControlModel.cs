﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using parking_control.Models;

namespace parking_control.Service.Model
{
    public class ValidityDateControlModel : BaseModel
    {        
        public static ValidityDateControl Select(DateTime InitialDate)
        {

            using (MySqlCommand command = new MySqlCommand(SqlSelect(InitialDate), ConnectMysql.GetInstance()))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    ValidateReader(reader);

                   return CreateDateControl(reader);
                }
            }
        }

        private static string SqlSelect(DateTime InitialDate)
        {
            string initialDateString = InitialDate.ToString("yyyy-MM-dd HH:mm:ss");
            string sql = string.Format(
                "SELECT * FROM ValidityDateControl WHERE InitialDate = \"{0}\""
                , initialDateString);
            return sql;
        }

        private static ValidityDateControl CreateDateControl(MySqlDataReader reader)
        {
            return new ValidityDateControl(reader.GetInt32(0), reader.GetDouble(1), reader.GetDateTime(2), reader.GetDateTime(3));
        }

        public static ValidityDateControl Select(int id)
        {
            Validate(id);

            ValidityDateControl dateControl = null;
            string sql = string.Format(
                "SELECT * FROM ValidityDateControl WHERE id = \"{0}\""
                , id);
            dateControl = RunCommand(id, sql);
            return dateControl;
        }

        private static ValidityDateControl RunCommand(int id, string sql)
        {
            using (MySqlCommand command = new MySqlCommand(sql, ConnectMysql.GetInstance()))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    ValidateReader(reader);

                    return CreateDateControl(id, reader);
                }
            }            
        }

        private static ValidityDateControl CreateDateControl(int id, MySqlDataReader reader)
        {
            return new ValidityDateControl(id, reader.GetDouble(1), reader.GetDateTime(2), reader.GetDateTime(3));
        }



        public static List<ValidityDateControl> SelectAll(int limit = 1000)
        {
            List<ValidityDateControl> listDateControl = new List<ValidityDateControl>();
            string sql = string.Format("SELECT * FROM ValidityDateControl LIMIT {0}", limit);
            RunCommand(listDateControl, sql);
            return listDateControl;
        }

        private static void RunCommand(List<ValidityDateControl> listDateControl, string sql)
        {
            using (MySqlCommand command = new MySqlCommand(sql, ConnectMysql.GetInstance()))
            {
                ExecuteCommand(listDateControl, command);
            }
        }

        private static void ExecuteCommand(List<ValidityDateControl> listDateControl, MySqlCommand command)
        {
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    AddToList(listDateControl, reader);
                }
            }
        }

        private static void AddToList(List<ValidityDateControl> listDateControl, MySqlDataReader reader)
        {
            listDateControl.Add(new ValidityDateControl(reader.GetInt32(0), reader.GetDouble(1), reader.GetDateTime(2), reader.GetDateTime(3)));
        }

        public static void Insert(ValidityDateControl dateControl)
        {
            using (MySqlCommand command = new MySqlCommand(string.Format(
                    "INSERT INTO ValidityDateControl (HourPrice, InitialDate, FinalDate) VALUES ({0}, \"{1}\", \"{2}\");"
                    , dateControl.HourPrice.ToString().Replace(",", "."), dateControl.InitialDate.ToString("yyyy-MM-dd HH:mm:ss"), dateControl.FinalDate.ToString("yyyy-MM-dd HH:mm:ss")), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }

        public static void Update(ValidityDateControl dateControl)
        {
            Validate(dateControl);

            using (MySqlCommand command = new MySqlCommand(SetUpdateSQL(dateControl), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }

        private static string SetUpdateSQL(ValidityDateControl dateControl)
        {
            string initialDate = dateControl.InitialDate.ToString("yyyy-MM-dd HH:mm:ss");
            string finalDate = dateControl.FinalDate.ToString("yyyy-MM-dd HH:mm:ss");
            return string.Format(
                    "UPDATE ValidityDateControl SET HourPrice={0}, InitialDate=\"{1}\", FinalDate=\"{2}\" WHERE id = {3};"
                    , dateControl.HourPrice.ToString().Replace(",", "."), initialDate, finalDate, dateControl.ID);

        }

        public static void DeleteAll()
        {
            using (MySqlCommand command = new MySqlCommand(string.Format("DELETE FROM ValidityDateControl"), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }

        public static void Delete(ValidityDateControl dateControl)
        {
            Validate(dateControl);

            using (MySqlCommand command = new MySqlCommand(string.Format("DELETE FROM ValidityDateControl WHERE id = {0}", dateControl.ID), ConnectMysql.GetInstance()))
            {
                command.ExecuteNonQuery();
            }
        }

        private static void Validate(ValidityDateControl dateControl)
        {
            if (dateControl.ID == 0)
                throw new NotFoundIDEntity("A objeto excluido não possue uma chave primária");
        }
    }

    
}