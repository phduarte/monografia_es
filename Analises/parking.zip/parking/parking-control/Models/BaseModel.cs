﻿using MySql.Data.MySqlClient;
using parking_control.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace parking_control.Service.Model
{
    public class BaseModel
    {
        public static void ValidateReader(MySqlDataReader reader)
        {
            if (!reader.Read())
                throw new NotExecuteCommandSql("Erro na leitura de uma data do banco ou a chave primária não existe na base");
        }

        public static void Validate(int id)
        {
            if (id == 0)
                throw new NotFoundIDEntity("A chave primaria não pode ser igual a 0");
        }
    }
}